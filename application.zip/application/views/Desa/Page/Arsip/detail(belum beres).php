<!-- Static Table Start -->
<div class="data-table-area mg-b-15">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="sparkline13-list">
                    <div class="sparkline13-hd">
                        <div class="main-sparkline13-hd">
                            <h1>Detil Arsip</h1>
                        </div>
                    </div>
                    <div class="sparkline13-graph">
                        <div class="datatable-dashv1-list custom-datatable-overright">
                            <div class="modal-bootstrap shadow-inner mg-tb-30 responsive-mg-b-0">
                                <div class="modal-area-button">
                                    <a class="Danger danger-color" href="<?= base_url('AdminDesa/Arsipdokumen')?>">Kembali</a>
                                    <a class="Primary mg-b-10" href="#" data-toggle="modal" data-target="#PrimaryModalalert">Simpan</a>
                                </div>
                            </div>
        z<div><iframe src="" frameborder="0" class=""></iframe></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
