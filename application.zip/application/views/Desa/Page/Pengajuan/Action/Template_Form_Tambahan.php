<!-- Template Form Tambahan [...START]-->
    <?php 
        include("Jenis_Dokumen/SKDomisili.php");
        // SK Belum Menikah
        include("Jenis_Dokumen/SKMenikah.php");
        include("Jenis_Dokumen/SKU.php");
        include("Jenis_Dokumen/SKKelahiran.php");
        include("Jenis_Dokumen/SKKematian.php");
        include("Jenis_Dokumen/SKTM.php");
    ?>
<!-- Template Form Tambahan [...END] -->