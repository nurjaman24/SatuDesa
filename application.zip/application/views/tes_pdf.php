<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tes PDF</title>
</head>
<body>
    
    <table>
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>File</th>
            <th>Aksi</th>
        </tr>
        <tr>
            <td>1</td>
            <td>Yan</td>
            <td>cv</td>
            <td><a href="<?= base_url('asset/persyaratan/Nirwana 1.pdf') ?>" target="_blank">View</a></td>
        </tr>
    </table>

</body>
</html>